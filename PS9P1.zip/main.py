
def compdiscamount(total, discrate): 
  discamount = (discrate/100) * total
  return discamount
def compdiscprice(discamount, total):
  discprice = (total - discamount)
  return discprice

quantity = float(input("Enter quantity: "))
price = float(input("Enter price: "))
discrate = float(input("Enter discount rate: "))
total = quantity * price


discamount = compdiscamount(discrate, total)
discprice = compdiscprice(discamount, total)
  

print("Discount amount: " , discamount)
print("Discounted price: " , discprice)






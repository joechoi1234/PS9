
def compavgscore(score1, score2, score3):
  avgscore = (score1 + score2 + score3) / 3
  return avgscore

def comphandicapscore(score1, score2, score3):
  handicapscore = avgscore + handicap
  return handicapscore 

lastname = input("Enter bowlers last name: ")
handicap = int(input("Enter handicap score: ")) 
score1 = int(input("Enter score 1: "))
score2 = int(input("Enter score 2: "))
score3 = int(input("Enter score 3: "))

avgscore = compavgscore(score1, score2, score3)
handicapscore = comphandicapscore(score1, score2, score3)

print("Average score: " , avgscore)
print("Average score with handicap: " , handicapscore)



  
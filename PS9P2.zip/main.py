

def compavgscore(test1, test2, test3):
  avgscore = (test1 + test2 + test3) / 3
  return avgscore

def comptotalscore(test1, test2, test3):
  totalscore = (test1 + test2 + test3)
  return totalscore

test1 = float(input("Enter exam 1: "))
test2 = float(input("Enter exam 2: "))
test3 = float(input("Enter exam 3: "))

avgscore = compavgscore(test1, test2, test3)
totalscore = comptotalscore(test1, test2, test3)

print("Average score: " , avgscore)
print("Total score: " , totalscore)


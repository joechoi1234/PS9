
def compcommission(sales, salesrate):
  commission = (salesrate * sales)
  return commission

lastname = input("Enter last name: ")
sales = float(input("Enter sales: "))
if sales > 100000:
  salesrate = 0.10
else:
  salesrate = .05

salesgoal = 0.95 * sales 

commission = compcommission(sales, salesrate)

print("Last name: " , lastname)
print("Commmission:  " , commission)
print("Next years target: " , salesgoal)

  

qty = int(input("Enter quantity of item: "))
price = int(input("Enter price of item: "))

def comptotal(qty, price):
  total = qty * price
  return total

def comptax(total):
  tax = total * .07
  return tax


total = comptotal(qty, price)
tax = comptax(total)

print("Total: " , total)
print("Tax: " , tax)
